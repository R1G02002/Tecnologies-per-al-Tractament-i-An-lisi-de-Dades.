# TTAD Subject Material

Authors: [Dr. Isaac Lera](https://personal.uib.es/isaac.lera), [Dr. Miquel Miró](https://personal.uib.cat/miquel.miro) <br/>
Official web site: [https://cep.uib.cat/master/MAD2/12174/index.html](https://cep.uib.cat/master/MAD2/12174/index.html) <br/>
Edition: 2025-26, v0.01<br/>

## How to read the doc

Documentation available at: [https://ttad.readthedocs.io/](https://ttad.readthedocs.io/)

